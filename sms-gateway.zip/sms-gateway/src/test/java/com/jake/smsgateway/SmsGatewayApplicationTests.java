package com.jake.smsgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
